from .triplet import Triplet

__all__ = ['Triplet']
